
<?php $__env->startSection('content'); ?>
    <!-- content -->
    <main class="py-5">
      <div class="container">
        <div class="row justify-content-md-center">
          <div class="col-md-8">
            <div class="card">
              <div class="card-header card-title">
                <strong>Add New Contact</strong>
              </div>  
              <form action="<?php echo e(route('contacts.store')); ?>" method='POST'>  
                <?php echo csrf_field(); ?>       
                <?php echo $__env->make('contacts._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </form>  
            </div>
          </div>
        </div>
      </div>
    </main>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\contact\resources\views/contacts/create.blade.php ENDPATH**/ ?>