<?php

namespace Database\Seeders;
use DB;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Company;
use App\Models\User;
use Faker\Factory as Faker;
class CompaniesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('companies')->delete();
        $companies = [];
        $faker=Faker::create();
        foreach (range(1,10) as $index)
        {
        $companies[]=[
            'name'=>$faker->company,
            'adress'=>$faker->address,
            'email'=>$faker->email,
            'website'=>$faker->domainName,
            'user_id'=>User::pluck('id')->random(),
            'created_at'=>now(),
            'updated_at'=>now(),
        ];
        }
        DB::table("companies")->insert($companies);
        
       
    }
}
