<?php

namespace Database\Factories;
use App\Models\Company;
use App\Models\User;
use Faker\Generator as Faker;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Company>
 */
class CompanyFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            'name' => $this->faker->company(),
            'adresse' => $this->faker->address(),
            'website' => $this->faker->domainName(),
            'email' => $this->faker->email(),
            'user_id'=>User::pluck('id')->random()
            
        ];
    }
}
