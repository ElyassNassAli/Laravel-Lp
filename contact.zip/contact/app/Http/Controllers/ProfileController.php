<?php

namespace App\Http\Controllers;
use App\Http\requests\ProfileUpdateRequest;

use Illuminate\Http\Request;

class ProfileController extends Controller
{
    public function edit(){

        return view('settings.profile',['user'=>auth()->user()]);
    }
    public function update(ProfileUpdateRequest $request ){
      
      $profileData =$request->handleRequest();  
      $request->user()->update($profileData);
      return back()->with('message',"profile has been updated successufully");
        
    }

}

