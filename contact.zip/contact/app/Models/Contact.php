<?php

namespace App\Models;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Scopes\FilterScope;
use App\Scopes\SearchScope;

class Contact extends Model
{
    protected $fillable = ['first_name','last_name','email','phone','adress','company_id'];
    use HasFactory;
   public function company(){
    return $this->belongsTo(Company::class);
   }
   public function user(){
    return $this->belongsTo(User::class);
   }
   public function scopeLatestFirst($query){

    return $query->orderBy('first_name','asc');
   }
   public static function boot()
   {
     parent::boot();

     static::addGlobalScope(new FilterScope);
     static::addGlobalScope(new SearchScope);
    
   }
   /*public function scopeFilter($query){
                if($companyId=request('company_id')){
                $query->where('company_id',$companyId);
            }
            if($search=request('search')){
                $query->where('first_name','LIKE',"%{$search}%");
            }
    return $query->orderBy('first_name','asc');
   }
   public function getRouteKeyName(){
       return 'first_name';
   }*/
}
